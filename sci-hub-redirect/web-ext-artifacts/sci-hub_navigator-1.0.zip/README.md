###### TODO:
- Read the HTML content of a page
- Read the attributes of an HTML content from a page - selected content
- Parse the content of selected contents and preview with the url
- Parse the url to meet specific standards - what are those standards??
- Final preview of url and specific content

###### Firefox build
__Accessing debug mode:__ about:debugging
